<?php 
$conn = new mysqli("localhost", "root", "root", "perpustakaan");

if ($conn->connect_errno) {
  echo "Koneksi Gagal, silahkan coba lihat DB: " . $conn->connect_error;
  exit();
}

function register($data) {
	global $conn;
	$nama = htmlspecialchars($data['nama']);
	$username = strtolower(stripslashes($data["username"]));
	$password = mysqli_real_escape_string($conn, $data["password"]);
	$password2 = mysqli_real_escape_string($conn, $data["password2"]);

	// jika username sudah terdaftar
	$result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username'");
	if( mysqli_fetch_assoc($result)) {
		echo "<script>
				alert('Username sudah terdaftar!'); 
					window.location='register.php';
			</script>";
		return false;
	}

	if($password !== $password2) {
		echo "<script>alert('konfirmasi password salah.');</script>";
		return false;
	}

	if(strlen($username) < 6 ) {
		echo "<script>alert('Password terlalu pendek, maksimal 6 digit');window.location='register.php';</script>";
		return false;
	}

	

	$password = password_hash($password, PASSWORD_DEFAULT);

	mysqli_query($conn, "INSERT INTO tb_user VALUES (null, '$username', '$password', '$nama')") or die(mysqli_error($conn));
	return mysqli_affected_rows($conn);
}

